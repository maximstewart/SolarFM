from .mixins import DesktopIconMixin
from .mixins import VideoIconMixin

from .Icon   import Icon
